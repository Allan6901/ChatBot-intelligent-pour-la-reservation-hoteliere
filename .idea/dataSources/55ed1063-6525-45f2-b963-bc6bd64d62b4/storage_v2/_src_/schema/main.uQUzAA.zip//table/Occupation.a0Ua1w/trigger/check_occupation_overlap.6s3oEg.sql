CREATE TRIGGER check_occupation_overlap
BEFORE INSERT ON Occupation
FOR EACH ROW
WHEN EXISTS (
    SELECT 1 FROM Occupation o
    WHERE o.num_ch_id = NEW.num_ch_id
      AND (
        (NEW.date_a BETWEEN o.date_a AND o.date_d)
        OR (NEW.date_d BETWEEN o.date_a AND o.date_d)
        OR (NEW.date_a <= o.date_a AND NEW.date_d >= o.date_d)
      )
)
BEGIN
    SELECT RAISE(ABORT, 'Erreur (C2): Chambre déjà occupée pendant cette période');
END;

