CREATE TRIGGER check_reservation_type_exists
BEFORE INSERT ON Reservation
FOR EACH ROW
WHEN NOT EXISTS (
    SELECT 1 FROM Chambre
    WHERE Chambre.num_ho_id = NEW.num_ho_id
      AND Chambre.num_ty_id = NEW.num_ty_id
)
BEGIN
    SELECT RAISE(ABORT, 'Erreur (C1): Hôtel ne possède aucune chambre de ce type');
END;

